from setuptools import find_packages, setup

package_name = 'delivery_robot'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='bhagad',
    maintainer_email='bhagad@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': ['auto_delivery = delivery_robot.auto_delivery:main',
                            'task_manager = delivery_robot.task_manager:main',
        ],
    },
)
