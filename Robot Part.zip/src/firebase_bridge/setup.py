from setuptools import setup

package_name = 'firebase_bridge'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
    ('share/ament_index/resource_index/packages',
        ['resource/' + package_name]),
    ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='bhagad',
    description='Firebase bridge node',
    license='Apache License 2.0',
    entry_points={
        'console_scripts': [
            'firebase_listener = firebase_bridge.firebase_listener:main',
        ],
    },
)
def main():
    print("working")
